# Layer Package File
Execute these commands to create the layer package file

    chmod +x get_layer_packages.sh
    ./get_layer_packages.sh
    zip -r my-Python36-Pandas23x.zip .